import {createStore} from 'vuex'
const store=createStore({
     state(){
         return{
             num:1,
         }
     },
    mutations:{
       changeNum(state,num){
           state.num=num;
       }
    },
    getters:{
         getterNum(state){
             return "你需要的数据是"+state.num;
         }
    },

    actions:{
         action1(context){
             context.commit("changeNum",2)
         }
    }
})

export default store;