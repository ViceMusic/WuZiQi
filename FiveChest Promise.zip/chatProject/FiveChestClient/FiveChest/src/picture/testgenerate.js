function* generate() {
    console.log("invoked 1st time"); // "invoked 1st time"
    yield* [1,1.5];
    console.log("invoked 2nd time"); // // "invoked 2nd time"
    yield 2;
}

let gen = generate();
//console.log(gen); // Object [Generator] {}

let result  = gen.next();
console.log(1);
console.log("result", result); // {value: 1, done: false}

let result1 = gen.next();
console.log(1.5);
console.log("result", result1); // {value: 2, done: false}

let result2 = gen.next();
console.log(2);
console.log("result", result2); // {value: undefined, done: true}

//generate函数有固定的执行区域,作用方法类似迭代器
//next仍然是指向"头节点",每一次next(),都会解锁并且执行全新yield的区域
//并且每次next以后返回的也是一个迭代器类型的对象,具有value和done两个属性

//yield相当于划分出一个执行区域
//每个next都会寻找下一个yield或者下一个yield数组的元素
//每次到达了一个新的yield或者yield*元素,,都会把中间的执行



async function main(){
    let  a= await Promise.resolve("ddd");
    console.log(a); //ddd
    let c=await Promise.reject("ddd");
    console.log(c); //ddd
    return 1;
}
const p=main();
console.log(p)