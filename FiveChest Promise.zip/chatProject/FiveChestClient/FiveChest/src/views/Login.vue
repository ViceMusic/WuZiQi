<template>
  <div id="bg">
    {{this.$store.state.num}}
    <button @click="this.$store.dispatch('action1')">jjjj</button>
    <div id="information">
      <p style="margin-left: 10%;">输入你的用户名,打开五子棋</p>
      <br>
      <input id="dd" v-model="username" style="background: rgba(0,0,0,0.1);height:50px;">
      <button @click="login(username)">登录</button>
    </div>
  </div>
</template>

<script>
import router from "../router";

export default {
  name: "Login",
  data(){
    return{
       username:"",
    }
  },
  methods:{
    login(name){
      if(name!==""){
        sessionStorage.setItem("user",name);
        router.push("/home");
      }else{
        console.log("请输入正确的名字");
      }
    }
  }
}
</script>

<style scoped>
#bg{

  background-image: url("../picture/地狱绘图.png");
  background-size: 100% 100%; /* 宽高都填满 */
  height: 1000px;
  position: relative;
}
#information{
  background: rgba(255,255,255,0.5);
  width: 300px;
  height: 100px;
  position: absolute;
  left: 680px;
  top: 400px;
}
</style>