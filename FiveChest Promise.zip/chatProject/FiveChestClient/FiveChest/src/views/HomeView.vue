<template>

  <!--牌局部分,如果接受了对局,就是这样了-->
  <div id="PlayRoom">
    <div v-show="isAccept">
      <canvas id="canvas" ref="canvas"></canvas>
      <br>目前是:{{isMyOperation===1?'你':'对手'}}的回合
      <br>你的对手为:{{ counterpart }}
      <button @click="leaveRoom()">离开对局</button>
    </div>

    <!---->
    <div id="player">
      <!--用户列表部分-->
      <div id="userList">
        <p style="background: burlywood;height: 50px;line-height: 50px;">&nbsp;&nbsp;&nbsp;在线玩家(:3 | ∠)</p>
        <div v-for="(user,index) in allUser">
          <div v-if="MyName!==user.username">
            <span style="color: #2c3e50">{{ user.username }}</span>在线
            <button @click="SubmitChallenge(user.username)">发出挑战</button>
          </div>
        </div>
      </div>
      <!--挑战者列表部分-->
      <div id="challengerList">
        <p style="background: burlywood;height: 50px;line-height: 50px;">&nbsp;&nbsp;&nbsp;棋局邀请&nbsp;or2</p>
        <div v-for="(challengeName,index) in allChallenge">
          {{ index }} : {{ challengeName }}玩家在线
          <button @click="acceptChallenge(index,challengeName)">接收挑战</button>
          <button @click="rejectChallenge(index,challengeName)">拒绝挑战</button>
        </div>
      </div>
      <!--聊天框部分-->
      <div id="chatBlock">
        <p style="background: gainsboro;height: 50px;line-height: 50px;">&nbsp;&nbsp;&nbsp;聊天区域(^_^)</p>
        <br>
        <input id="dd" v-model="toUsername">
        <br>
        <textarea id="text" v-model="content">
    </textarea>
        <button @click="hello()">
          点击发送给这名玩家
        </button>
      </div>
      <!--世界频道部分-->
      <div id="allChatBlock">
        <p style="background: gainsboro;height: 50px;line-height: 50px;">&nbsp;&nbsp;&nbsp;公共服务器(^_^)</p>
        <div style="overflow: auto;height: 150px;background: darkgray">
          <div v-for="(message) in arrALLMessage">
            &nbsp;&nbsp;&nbsp;{{message}}
          </div>
        </div>
        <br>
        <textarea id="text" v-model="allMessage">
      </textarea>
        <button @click="toAllMessage()">
          点击发送到世界频道
        </button>
      </div>
    </div>

  </div>

</template>


<script>
import {markRaw, ref} from "vue";

export default {
  name: "Login",
  data() {
    return {
      toUsername: "",
      content: "",
      ws: "",
      allUser: "",
      allChallenge: [],
      isAccept: 0,
      counterpart: "",
      arr: [],
      player: 0,
      canvas:"",
      ctx:"",
      isMyOperation:0,
      MyName:"",
      allMessage:"",
      arrALLMessage:[]
    }
  },
  mounted() {
    const self = this;
    //这个登录机制有可能还需要改一下
    let MyUsername = sessionStorage.getItem("user");
    self.MyName=MyUsername;
    //这个后台按需要更新
    this.ws = new WebSocket("ws://127.0.0.1:8080/imserver/" + MyUsername);

    this.ws.onopen = function () {
      console.log("玩家" + MyUsername + "已经登录")
    }

    this.ws.onclose=function(){
      let oj={
        signal:8,
        to:self.counterpart
      }
      self.ws.send(JSON.stringify(oj));
    }

    this.ws.onmessage = function (event) {
      let oj = JSON.parse(event.data);

      if (oj.signal === 2) {                  //玩家的信息
        console.log("来自玩家" + oj.from + "的消息:" + oj.text)
      } else if (oj.signal === 1) {               //系统消息
        let arr = oj.users;
        self.allUser = ref(arr);
        for (let i = 0; i < arr.length; i++) {
          console.log(arr[i].username + "玩家在线");
        }
      } else if (oj.signal === 3) { //别人发来的请战消息,加入等待队列中
        self.allChallenge.push(oj.from);
      } else if (oj.signal === 4) { //别人发来的请战消息,加入等待队列中
        if (oj.agree === 1) {
          console.log("玩家" + oj.from + "已经接收了您的对局邀请");
          self.counterpart = oj.from;
          self.isAccept = 1;//代表接受对局
          self.player=2;//设置为客场玩家
          self.isMyOperation=1;//设置为先手
          self.reHandleCross();
        } else {
          console.log("玩家" + oj.from + "已经拒绝了您的对局邀请")
        }
      }else if (oj.signal === 5) { //别人发来的操作消息
         let x=oj.x;
         let y=oj.y;
         self.arr[x][y]=self.player%2+1;
         reFlash();
         self.isMyOperation=1;//别人操作完了,才能是自己
      }else if (oj.signal === 6) { //胜利了
         alert(oj.context);
         self.arrALLMessage.push("玩家"+MyUsername+"暴捶了"+self.counterpart)
         clearChest();
         self.isAccept=0;//退出房间
         self.counterpart="";
         self.player=0;
      }else if (oj.signal === 7) { //失败了
         alert(oj.context);
         clearChest();
         self.isAccept=0;//退出房间
         self.counterpart="";
         self.player=0;
      }else if (oj.signal === 9) { //对面掉线了
        alert("你的对手掉线了");
        clearChest();
        self.isAccept=0;//退出房间
        self.counterpart="";
        self.player=0;
      }else if (oj.signal === 10) {
        let from=oj.from;
        let context=oj.context;
        self.arrALLMessage.push("["+from+"]"+":"+context);
      }
    }

    //数组编写
    for (let i = 0; i < 16; i++) {
      const row = [];
      for (let j = 0; j < 16; j++) row.push(0); // 这里初始化为 0，可以根据需要改为其他值
      self.arr.push(row);
    }

    //建立画布
    self.canvas=self.$refs.canvas;
    self.canvas.width = 500; // 设置画布的宽度为500像素
    self.canvas.height = 500; // 设置画布的高度为500像素
    self.ctx=self.canvas.getContext("2d");
    //画布的宽高应该是手动设置或者在标签中设置,而不是利用css

     //每次操作时候刷新棋盘的操作,会把新的点画上去
      function reFlash(){
        for (let i = 0; i < 16; i++) {
          for (let j = 0; j < 16; j++){
            if(self.arr[i][j]===1){
              self.ctx.beginPath();
              self.ctx.fillStyle="#000000";
              self.ctx.arc(i*30+25,j*30+25,12,0,2*Math.PI,false);
              self.ctx.fill();
            }else if(self.arr[i][j]===2){
              self.ctx.beginPath();
              self.ctx.fillStyle="#FFFFFF";
              self.ctx.arc(i*30+25,j*30+25,12,0,2*Math.PI,false);
              self.ctx.fill();
            }
          }
        }
      }

      //刷新清空棋盘
      function clearChest(){       //重新绘制棋盘的方法
        alert("已经退出房间");
        for (let i = 0; i < 16; i++) {     //先刷新数据
          for (let j = 0; j < 16; j++){
            self.arr[i][j]=0;
          }
        }
        self.ctx.clearRect(0,0,500,500);  //再重画棋盘
        for(var i=25;i<=480;i+=30){
          self.ctx.beginPath();
          self.ctx.moveTo(i,25);
          self.ctx.lineTo(i,475);
          self.ctx.stroke();
        }
        for(var i=25;i<=480;i+=30){
          self.ctx.beginPath();
          self.ctx.moveTo(25,i);
          self.ctx.lineTo(475,i);
          self.ctx.stroke();
        }
      }

      //监听鼠标信息
      self.canvas.addEventListener('click', function(event) {
        // 获取鼠标在窗口中的位置
        const mouseX = event.clientX;
        const mouseY = event.clientY;

        // 获取 Canvas 元素在窗口中的位置和大小
        const canvasRect = self.canvas.getBoundingClientRect();

        // 计算鼠标在 Canvas 上的位置
        const canvasX = mouseX - canvasRect.left;
        const canvasY = mouseY - canvasRect.top;

        var x=(canvasX-25)%30;
        var y=(canvasY-25)%30;
        if(x>=15)   x=(canvasX+5-(canvasX-25)%30)/30;  //两种情况的转化
        else        x=(canvasX-25-(canvasX-25)%30)/30;
        if(y>=15)   y=(canvasY+5-(canvasY-25)%30)/30;
        else        y=(canvasY-25-(canvasY-25)%30)/30;

        if(x<0 || x>15 || y<0 || y>15) alert("出界限了");
        else if(self.arr[x][y] !== 0) alert("不能在此处下棋");
        else if(self.isMyOperation===0)  { alert("现在不是您下棋的时候");}
        else{
          console.log("玩家"+self.player+":"+`Mouse position: (${x}, ${y})`);
          self.arr[x][y]=self.player;
          reFlash();
          //把自己棋盘的数据更新以后,也要告诉对手自己的棋盘更新了
          console.log(JSON.stringify(self.arr));
          let jo={
            signal:5,
            to:self.counterpart,
            chest:JSON.stringify(self.arr),
            x:x,
            y:y
          };
          self.isMyOperation=0;//每次自己操作完以后,就不能继续操作了,要等对方的信息
          self.ws.send(JSON.stringify(jo));
        }
      });

    },
  methods: {
    //向玩家通过控制台发送聊天信息
    hello() {
      let oj = {
        signal: 2,
        to: this.toUsername,
        text: this.content
      }
      console.log("你:" + oj.text)
      this.ws.send(JSON.stringify(oj));
    },
    SubmitChallenge(username) {
      let oj = {
        signal: 3,
        to: username
      }
      this.ws.send(JSON.stringify(oj));
    },
    removeChallenge(index) {
      this.allChallenge.splice(index, 1);
    },
    acceptChallenge(index, name) {
      let oj = {
        signal: 4,
        to: name,
        accept: 1
      }
      this.isAccept = 1;
      this.player = 1;
      this.counterpart = name;
      this.isMyOperation=0;
      this.removeChallenge(index);
      console.log("您已经接受了来自" + name + "的对局邀请");
      this.reHandleCross(); //画上空白的棋盘
      this.ws.send(JSON.stringify(oj));
    },
    rejectChallenge(index, name) {
      let oj = {
        signal: 4,
        to: name,
        accept: 0
      }
      this.removeChallenge(index);
      console.log("您已经拒绝了来自" + name + "的对局邀请");
      this.ws.send(JSON.stringify(oj));
    },
    leaveRoom() {
      alert("您选择了主动离开房间")
      let oj={
        signal:8,
        to:this.counterpart
      }
      this.ws.send(JSON.stringify(oj));
      this.isAccept = 0;
      this.counterpart = "";
      this.isMyOperation=0;
      this.player=0;

    },
    reHandleCross(){
      const self=this;
      for(var i=25;i<=480;i+=30){
        self.ctx.beginPath();
        self.ctx.moveTo(i,25);
        self.ctx.lineTo(i,475);
        self.ctx.stroke();
      }
      for(var i=25;i<=480;i+=30){
        self.ctx.beginPath();
        self.ctx.moveTo(25,i);
        self.ctx.lineTo(475,i);
        self.ctx.stroke();
      }
    },
    toAllMessage(){
      let oj = {
        signal: 10,
        context: this.allMessage
      }
      this.arrALLMessage.push("["+"你"+"]:"+this.allMessage)
      this.ws.send(JSON.stringify(oj));
    }

  }
}

</script>

<style>

#canvas{
  border-style: solid;
  background: saddlebrown;
}
#userList {
  float: right;
  background: bisque;
  height: 150px;
  width: 500px;
  overflow: auto;
}
#challengerList{
  float: right;
  clear: right;
  background: blanchedalmond;
  height: 150px;
  width: 500px;
  overflow: auto;
}
#chatBlock{
  float: right;
  clear: right;
  background: gray;
  height: 200px;
  width: 500px;

}
#allChatBlock{
  float: right;
  clear: right;
  background: gray;
  height: 300px;
  width: 500px;

}
#player{
  position: fixed;
  top: 0px;
  right: 0px;
}
input{
  border-radius: 6px;
  border-style: none;
  margin-left: 20px;
}
textarea{
  border-radius: 6px;
  border-style: none;
  margin-top: 5px;
  margin-left: 20px;
  background:rgba(255,255,255,0.5);
  height: 50px;
  width: 200px;
}
button{
  border-radius: 6px;
  border-style: none;
  margin-left: 20px;
  color: white;
  background: cornflowerblue;
}
#PlayRoom{
  background-image: url("../picture/房间页面.png");
  background-size: 100% 100%; /* 宽高都填满 */
  height: 1200px;
  position: relative;
}
</style>