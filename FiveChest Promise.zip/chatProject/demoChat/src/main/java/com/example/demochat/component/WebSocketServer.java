package com.example.demochat.component;


import cn.hutool.json.JSON;
import com.fasterxml.jackson.databind.util.JSONPObject;
import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

//建立一个双通道的webSocket类

@ServerEndpoint("/imserver/{username}")
//这是一个声明,声明这里是服务器的终端,可以通过这个路径访问
//{}代表占位符,可以通过@PathParam注解获取这个参数
@Component
public class WebSocketServer {

    //创建容器,存储会话链接数目
    public static final Map<String, Session> sessionMap=new ConcurrentHashMap<>();
    //ConcurrentHashMap是一种线程安全的哈希表允许多个线程同时对表进行操作，而不会引起数据的不一致或线程阻塞。

    //下面是四个基础方法,当触发对应事件的时候,注解就会调用这些方法

    //得到所有的在线用户的列表,并且返回给前端
    @OnOpen
    public void onOpen(Session session, @PathParam("username") String username) throws IOException {
           sessionMap.put(username,session);
           System.out.println("链接用户为"+username+",目前在线人数为:"+sessionMap.size());
           //接下来把所有用户按照序号组装成数组,再编成json传入前端,
           updateUserList(session,username);
    }

    //移除某个用户
    @OnClose
    public void onClose(Session session, @PathParam("username") String username) throws IOException {
           sessionMap.remove(username);
           System.out.println("用户"+username+",已经退出,当前在线人数剩余"+sessionMap.size());

           updateUserList(session,username);
    }

    //可以视为一个消息的中转站
    //把Message是一个json对象
    //接收消息,并且传给另一个人

    @OnMessage
    public void onMessage(String message,Session session,@PathParam("username") String username) throws IOException {
           JSONObject jsonObject=JSONUtil.parseObj(message);
           int signal=jsonObject.getInt("signal");//来源
           switch (signal){
               case 1: System.out.println("收到系统调用消息");    break;
               case 2: sendMessageToSomeone(jsonObject,message,session,username);   break;
               case 3: sendMessageToChallengeSomeone(jsonObject,message,session,username);    break;
               case 4: sendMessageToReplyChallengeFromSomeone(jsonObject,message,session,username);   break;
               case 5: sendMessageToChangeChest(jsonObject,message,session,username);   break;
               case 8: sendMessageToInformSomeoneIamLeave(jsonObject,message,session,username);   break;
               case 10: sendMessageToAll(jsonObject,message,session,username);   break;
           }

    }


    @OnError
    public void onError(Session session , Throwable err){//这里的参数类型必须是可抛出"Throwable"
       System.out.println("有问题力");
    }

    //向所有链接发送消息
    public void sendAllMessage(String message) throws IOException {
        //向所有的会话发送信息
        for(Session session : sessionMap.values()){
            session.getBasicRemote().sendText(message);
        }
    }

    //向某个链接发送消息,这个方法是自动注入OnMessage中
    //
    public void sendMessage(String message,Session session) throws IOException {
        //向所有某个会话发送信息
        try{
            session.getBasicRemote().sendText(message);
        }catch (Exception e){
            System.out.println("发送出现问题");
        }
    }

    public void updateUserList(Session session,String username) throws IOException {
        JSONObject result=new JSONObject();
        JSONArray array=new JSONArray();
        for(Object key:sessionMap.keySet()){
            JSONObject jo=new JSONObject();
            jo.set("username",key); //玩家姓名
            array.add(jo);
        }
        result.set("signal",1); // 1代表是系统的信息,2代表是玩家的信息
        result.set("users",array);
        sendAllMessage(JSONUtil.toJsonStr(result));//这个方法存疑,因为工具包不一样;
    }
    //signal1:向所有人发送消息
    public void sendMessageToAll(JSONObject jsonObject,String message,Session session,String username) throws IOException {
        String context=jsonObject.getStr("context");//文字
        for(String userName : sessionMap.keySet()){
            if(!Objects.equals(userName, username)){
                Session toSession=sessionMap.get(userName);
                JSONObject jo=new JSONObject();
                jo.set("signal",10);
                jo.set("from",username);
                jo.set("context",context);
                sendMessage(JSONUtil.toJsonStr(jo),toSession);
            }
        }
    }
    //signal2:向某人发送下消息
    public void sendMessageToSomeone(JSONObject jsonObject,String message,Session session,String username) throws IOException {
        String toUsername=jsonObject.getStr("to");//来源
        String text=jsonObject.getStr("text");   //文本内容
        Session toSession=sessionMap.get(toUsername);
        if(toSession!=null){
            JSONObject jo=new JSONObject();
            jo.set("signal",2);
            jo.set("from",username);
            jo.set("text",text);
            sendMessage(JSONUtil.toJsonStr(jo),toSession);
        }else{
            System.out.println("onMessage方法发送出现问题1");
        }
    }
    //signal3:向某人发送挑战消息
    public void sendMessageToChallengeSomeone(JSONObject jsonObject,String message,Session session,String username) throws IOException {
        String toUsername=jsonObject.getStr("to");//向什么人发送信息
        Session toSession=sessionMap.get(toUsername);
        if(toSession!=null){
            JSONObject jo=new JSONObject();
            jo.set("signal",3);
            jo.set("from",username);
            sendMessage(JSONUtil.toJsonStr(jo),toSession);
        }else{
            System.out.println("onMessage方法发送出现问题1");
        }
    }
    //signal4:回应某人发送的挑战信息
    public void sendMessageToReplyChallengeFromSomeone(JSONObject jsonObject,String message,Session session,String username) throws IOException {
        String toUsername=jsonObject.getStr("to");//向什么人发送信息
        int accept=jsonObject.getInt("accept");
        Session toSession=sessionMap.get(toUsername);
        if(toSession!=null){
            JSONObject jo=new JSONObject();
            jo.set("signal",4);
            jo.set("agree",accept);//accept0代表对方没同意,accept代表对方同意了
            jo.set("from",username);
            sendMessage(JSONUtil.toJsonStr(jo),toSession);
        }else{
            JSONObject jo=new JSONObject();
            jo.set("signal",6);
            jo.set("context","对方可能已经离线了");
            sendMessage(JSONUtil.toJsonStr(jo),session);
        }
    }
    public void sendMessageToChangeChest(JSONObject jsonObject,String message,Session session,String username) throws IOException {
        String toUsername=jsonObject.getStr("to");//向什么人发送信息
        String jsonStr=jsonObject.getStr("chest");
        int x=jsonObject.getInt("x");//向什么人发送信息
        int y=jsonObject.getInt("y");
        JSONArray jsonArray = new JSONArray(jsonStr);

        int[][] array = new int[jsonArray.size()][((JSONArray) jsonArray.get(0)).size()];

        for (int i = 0; i < jsonArray.size(); i++) {
            JSONArray row = jsonArray.getJSONArray(i);
            for (int j = 0; j < row.size(); j++) {
                array[i][j] = row.getInt(j);
            }
        }

        System.out.println("玩家"+username+"在"+x+","+y+"位置下棋为"+array[x][y]);
        //-------------------
        Session toSession=sessionMap.get(toUsername);
        if(toSession!=null){
            JSONObject jo=new JSONObject();
            jo.set("signal",5);
            jo.set("x",x);
            jo.set("y",y);
            sendMessage(JSONUtil.toJsonStr(jo),toSession);
        }else{
            JSONObject jo1=new JSONObject();
            jo1.set("signal",9);//9代表有人掉线了
            sendMessage(JSONUtil.toJsonStr(jo1),session);
        }
        //是这样,发送最后一次信息的人一定是胜利者
        if(checkWinner(array)!=0){
            JSONObject jo1=new JSONObject();
            jo1.set("signal",6);
            jo1.set("context","获得了胜利");
            JSONObject jo2=new JSONObject();
            jo2.set("signal",7);
            jo2.set("context","您失败了");
            sendMessage(JSONUtil.toJsonStr(jo1),session);
            sendMessage(JSONUtil.toJsonStr(jo2),toSession);
        }

    }
    public int checkWinner(int[][] board) {
        int rows = board.length;
        int cols = board[0].length;
        // 检查横向
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols - 4; j++) {
                if (board[i][j] != 0 &&
                        board[i][j] == board[i][j + 1] &&
                        board[i][j] == board[i][j + 2] &&
                        board[i][j] == board[i][j + 3] &&
                        board[i][j] == board[i][j + 4]) {
                    return board[i][j];
                }
            }
        }

        // 检查纵向
        for (int i = 0; i < rows - 4; i++) {
            for (int j = 0; j < cols; j++) {
                if (board[i][j] != 0 &&
                        board[i][j] == board[i + 1][j] &&
                        board[i][j] == board[i + 2][j] &&
                        board[i][j] == board[i + 3][j] &&
                        board[i][j] == board[i + 4][j]) {
                    return board[i][j];
                }
            }
        }

        // 检查左上到右下斜向
        for (int i = 0; i < rows - 4; i++) {
            for (int j = 0; j < cols - 4; j++) {
                if (board[i][j] != 0 &&
                        board[i][j] == board[i + 1][j + 1] &&
                        board[i][j] == board[i + 2][j + 2] &&
                        board[i][j] == board[i + 3][j + 3] &&
                        board[i][j] == board[i + 4][j + 4]) {
                    return board[i][j];
                }
            }
        }

        // 检查左下到右上斜向
        for (int i = 4; i < rows; i++) {
            for (int j = 0; j < cols - 4; j++) {
                if (board[i][j] != 0 &&
                        board[i][j] == board[i - 1][j + 1] &&
                        board[i][j] == board[i - 2][j + 2] &&
                        board[i][j] == board[i - 3][j + 3] &&
                        board[i][j] == board[i - 4][j + 4]) {
                    return board[i][j];
                }
            }
        }

        // 无人获胜
        return 0;
    }
    public void sendMessageToInformSomeoneIamLeave(JSONObject jsonObject,String message,Session session,String username) throws IOException {
        String toUsername=jsonObject.getStr("to");//向什么人发送信息
        Session toSession=sessionMap.get(toUsername);
        if(toSession!=null){
            JSONObject jo1=new JSONObject();
            jo1.set("signal",6);
            jo1.set("context","你的对手主动离开了房间");
            JSONObject jo2=new JSONObject();
            jo2.set("signal",7);
            jo2.set("signal","您自己选择退出了房间");
            //谁先退出房间就算谁输了
            sendMessage(JSONUtil.toJsonStr(jo1),toSession);
            sendMessage(JSONUtil.toJsonStr(jo2),session);
        }else{
            System.out.println("方法发送出现问题");
        }
    }

}
